/* header file with definitions and decalarations of stuff used in 
   the file mexSSDHandler.h */

#include "dLsm.h"
#include "mexUtils.h"

int mat2dlsmImg(DLSMIMAGE*,mxArray*);
mxArray* dlsmImg2mat(DLSMIMAGE*);
int wh2nm(int*,mxArray*);


void packResult(mxArray*,DLSMMAINSTRUCT*);
