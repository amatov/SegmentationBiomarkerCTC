function runGrabTool();
%RUNGRABTOOL starts the grab tool
%
% SYNOPSIS runGrabTool();


% c: 09/05/00 dT
% changed from inconsistent function / file naming: 12/09/00 gD

a=grabtool;
a=opengrabpanel(a);

