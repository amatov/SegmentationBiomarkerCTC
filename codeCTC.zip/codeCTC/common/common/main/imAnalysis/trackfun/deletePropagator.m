function deletePropagator()
%DELETEPROPAGATOR removes coordinate propagator
%
% SYNOPSIS deleetPropagator()
%
% INPUT : none 
%
% OUTPUT : none

global prop__;

clear global prop__;
