function c=mtimes(a,b)
% This functions implements the times operator for variables of class int8
%
% Aaron Ponti, May 7th, 2004

% Min and max values allowed
cmin=-128;
cmax=127;

% Perform the summation operation
c=double(a)*double(b);

% Check for possible overflows
if any(c(:)<cmin) | any(c(:)>cmax)
    error('Result out of range.')
else
    c=int8(c);
end
