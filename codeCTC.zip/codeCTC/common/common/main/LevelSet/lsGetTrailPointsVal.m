dist_fct = lsGetTrailPointsVal(trial_grid_points, domain)



% first find the neighbourhood situation for each trail point
% see page 134 in Sethian
% case 1: 
%