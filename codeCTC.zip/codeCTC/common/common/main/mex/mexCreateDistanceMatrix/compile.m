disp('--> createDistanceMatrix.dll')
clear mex
mex createDistanceMatrix.c distmat.c