function uiViewMenuZoomOutFnc
% callback function

zoom(gcbf,'out');

