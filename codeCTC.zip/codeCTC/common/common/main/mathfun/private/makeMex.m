%% compile commands for all mex files in this directory
clear mex;
mex mexLineRegression.c ../../mexCalls/mexDataConverters.c num.lib -f mexOpts.bat