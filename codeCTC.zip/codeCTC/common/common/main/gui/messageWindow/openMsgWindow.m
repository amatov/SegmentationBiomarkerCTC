function openMsgWindow

% Opens/activates display
msgH=findobj('Tag','DISPLAY_MSG');
if isempty(msgH)
   msgH=displayMsg;
else
   figure(msgH)
end

