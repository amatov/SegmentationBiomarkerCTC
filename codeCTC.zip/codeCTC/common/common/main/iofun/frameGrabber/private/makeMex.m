%% compile commands for all mex files in this directory
clear mex;
% mex -DVERBOSE mexDTFgHandler.c olimg32.lib olfg32.lib -f dtFgOpts.bat
mex mexDTFgHandler.c olimg32.lib olfg32.lib -f dtFgOpts.bat
