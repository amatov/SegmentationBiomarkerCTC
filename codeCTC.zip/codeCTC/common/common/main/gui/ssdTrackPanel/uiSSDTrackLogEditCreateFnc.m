function uiSSDTrackLogEditCreateFnc
% call back for the log fielname edit field in the SSD Track panel

set(gcbo,'String',strcat(pwd,filesep,...
   uiSSDTrackPanelGetDflt('logfname')));
