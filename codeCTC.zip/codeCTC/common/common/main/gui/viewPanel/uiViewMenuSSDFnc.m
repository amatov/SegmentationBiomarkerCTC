function uiViewMenuSSDFnc
% callback function for the view panel menu

runUiSSDTrackPanel(gcbf);
