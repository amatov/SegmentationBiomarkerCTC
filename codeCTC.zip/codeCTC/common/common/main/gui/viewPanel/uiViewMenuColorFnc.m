function uiViewMenuColorFnc
%
% callback for colors menu

i =ImAdjustTool(gcbf);
DoImageAdjust(i);