function uiViewMenuAcqFnc
%
% callback function

runGrabTool;
