function y = feqZero(x)

% derivative of non-linear line filtering response

y = -(x+1/2)*exp(-1/2*(x+1/2).^2/(x.^2)) + ...
   +(x-1/2)*exp(-1/2*(x-1/2).^2/(x.^2));